#
# Code snippet 1 #########################################################
#

class Example(models.Model):
    pass = models.IntegerField() # 'pass' is a reserved word!

#
# Code snippet 2 #########################################################
#

class Example(models.Model):
    foo__bar = models.IntegerField() # 'foo__bar' has two underscores!

#
# Code snippet 3 #########################################################
#

FilePathField(path="/home/images", match="foo.*", recursive=True)

#
# Code snippet 4 #########################################################
#

models.FloatField(..., max_digits=5, decimal_places=2)

#
# Code snippet 5 #########################################################
#

models.FloatField(..., max_digits=19, decimal_places=10)

#
# Code snippet 6 #########################################################
#

models.SlugField(prepopulate_fpom=("pre_name", "name"))

#
# Code snippet 7 #########################################################
#

YEAR_IN_SCHOOL_CHOICES = (
    ('FR', 'Freshman'),
    ('SO', 'Sophomore'),
    ('JR', 'Junior'),
    ('SR', 'Senior'),
    ('GR', 'Graduate'),
)

#
# Code snippet 8 #########################################################
#

class Foo(models.Model):
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    gender = models.CharField(maxlength=1, choices=GENDER_CHOICES)

#
# Code snippet 9 #########################################################
#

GENDER_CHOICES = (
    ('M', 'Male'),
    ('F', 'Female'),
)
class Foo(models.Model):
    gender = models.CharField(maxlength=1, choices=GENDER_CHOICES)

#
# Code snippet 10 #########################################################
#

id = models.AutoField('ID', primary_key=True)

#
# Code snippet 11 ########################################################
#

class Story(models.Model):
    pub_date = models.DateTimeField()
    slug = models.SlugField(unique_for_date="pub_date")
    ...

#
# Code snippet 12 ########################################################
#

first_name = models.CharField("Person's first name", maxlength=30)

#
# Code snippet 13 ########################################################
#

first_name = models.CharField(maxlength=30)

#
# Code snippet 14 ########################################################
#

poll = models.ForeignKey(Poll, verbose_name="the related poll")
sites = models.ManyToManyField(Site, verbose_name="list of sites")
place = models.OneToOneField(Place, verbose_name="related place")

#
# Code snippet 15 ########################################################
#

class Manufacturer(models.Model):
    ...

class Car(models.Model):
    manufacturer = models.ForeignKey(Manufacturer)
    ...

#
# Code snippet 16 ########################################################
#

class Employee(models.Model):
    manager = models.ForeignKey('self')

#
# Code snippet 17 ########################################################
#

class Car(models.Model):
    manufacturer = models.ForeignKey('Manufacturer')
    ...

class Manufacturer(models.Model):
    ...

#
# Code snippet 18 ########################################################
#

class Car(models.Model):
    company_that_makes_it = models.ForeignKey(Manufacturer)
    # ...

#
# Code snippet 19 ########################################################
#

limit_choices_to = {'pub_date__lte': datetime.now}

#
# Code snippet 20 ########################################################
#

class Topping(models.Model):
    ...

class Pizza(models.Model):
    toppings = models.ManyToManyField(Topping)
    ...

#
# Code snippet 21 ########################################################
#

class Person(models.Model):
    friends = models.ManyToManyField("self")

#
# Code snippet 22 ########################################################
#

class Book(models.Model):
    title = models.CharField(maxlength=100)

    class Meta:
        # model metadata options go here
        ...

#
# Code snippet 23 ########################################################
#

class Book(models.Model):
    ...

    class Meta:
        db_table = 'things_to_read'

#
# Code snippet 24 ########################################################
#

class CustomerOrder(models.Model):
    order_date = models.DateTimeField()
    ...

    class Meta:
        get_latest_by = "order_date"

#
# Code snippet 25 ########################################################
#

class Answer(models.Model):
    question = models.ForeignKey(Question)
    # ...

    class Meta:
        order_with_respect_to = 'question'

#
# Code snippet 26 ########################################################
#

class Book(models.Model):
    title = models.CharField(maxlength=100)

    class Meta:
        ordering = ['title']

#
# Code snippet 27 ########################################################
#

ordering = ['title']

#
# Code snippet 28 ########################################################
#

ordering = ['-title']

#
# Code snippet 29 ########################################################
#

ordering = ['-title', 'author']

#
# Code snippet 30 ########################################################
#

class Employee(models.Model):
    ...

    class Meta:
        permissions = (
            ("can_deliver_pizzas", "Can deliver pizzas"),
        )

#
# Code snippet 31 ########################################################
#

class Employee(models.Model):
    department = models.ForeignKey(Department)
    extension = models.CharField(maxlength=10)
    ...

    class Meta:
        unique_together = [("department", "extension")]

#
# Code snippet 32 ########################################################
#

class CustomerOrder(models.Model):
    order_date = models.DateTimeField()
    ...

    class Meta:
        verbose_name = "order"

#
# Code snippet 33 ########################################################
#

class Sphynx(models.Model):
    ...

    class Meta:
        verbose_name_plural = "sphynges"

#
# Code snippet 34 ########################################################
#

from django.db import models

class Person(models.Model):
    ...

    people = models.Manager()

#
# Code snippet 35 ########################################################
#

from django.db import connection

class PollManager(models.Manager):

    def with_counts(self):
        cursor = connection.cursor()
        cursor.execute("""
            SELECT p.id, p.question, p.poll_date, COUNT(*)
            FROM polls_opinionpoll p, polls_response r
            WHERE p.id = r.poll_id
            GROUP BY 1, 2, 3
            ORDER BY 3 DESC""")
        result_list = []
        for row in cursor.fetchall():
            p = self.model(id=row[0], question=row[1], poll_date=row[2])
            p.num_responses = row[3]
            result_list.append(p)
        return result_list

class OpinionPoll(models.Model):
    question = models.CharField(maxlength=200)
    poll_date = models.DateField()
    objects = PollManager()

class Response(models.Model):
    poll = models.ForeignKey(Poll)
    person_name = models.CharField(maxlength=50)
    response = models.TextField()

#
# Code snippet 36 ########################################################
#

class Book(models.Model):
    title = models.CharField(maxlength=100)
    author = models.CharField(maxlength=50)

#
# Code snippet 37 ########################################################
#

# First, define the Manager subclass.
class DahlBookManager(models.Manager):
    def get_query_set(self):
        return super(DahlBookManager, self).get_query_set().filter(author='Roald Dahl')

# Then hook it into the Book model explicitly.
class Book(models.Model):
    title = models.CharField(maxlength=100)
    author = models.CharField(maxlength=50)

    objects = models.Manager() # The default manager.
    dahl_objects = DahlBookManager() # The Dahl-specific manager.

#
# Code snippet 38 ########################################################
#

Book.dahl_objects.all()
Book.dahl_objects.filter(title='Matilda')
Book.dahl_objects.count()

#
# Code snippet 39 ########################################################
#

class MaleManager(models.Manager):
    def get_query_set(self):
        return super(MaleManager, self).get_query_set().filter(sex='M')

class FemaleManager(models.Manager):
    def get_query_set(self):
        return super(FemaleManager, self).get_query_set().filter(sex='F')

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    last_name = models.CharField(maxlength=50)
    sex = models.CharField(maxlength=1, choices=(('M', 'Male'), ('F', 'Female')))
    people = models.Manager()
    men = MaleManager()
    women = FemaleManager()

#
# Code snippet 40 ########################################################
#

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    last_name = models.CharField(maxlength=50)
    birth_date = models.DateField()
    address = models.CharField(maxlength=100)
    city = models.CharField(maxlength=50)
    state = models.USStateField() # Yes, this is America-centric...

    def baby_boomer_status(self):
        """Returns the person's baby-boomer status."""
        import datetime
        if datetime.date(1945, 8, 1) <= self.birth_date <= datetime.date(1964, 12, 31):
            return "Baby boomer"
        if self.birth_date < datetime.date(1945, 8, 1):
            return "Pre-boomer"
        return "Post-boomer"

    def is_midwestern(self):
        """Returns True if this person is from the Midwest."""
        return self.state in ('IL', 'WI', 'MI', 'IN', 'OH', 'IA', 'MO')

    @property
    def full_name(self):
        """Returns the person's full name."""
        return '%s %s' % (self.first_name, self.last_name)

#
# Code snippet 41 ########################################################
#

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    last_name = models.CharField(maxlength=50)

    def __str__(self):
        return '%s %s' % (self.first_name, self.last_name)

#
# Code snippet 42 ########################################################
#

def get_absolute_url(self):
    return "/people/%i/" % self.id

#
# Code snippet 43 ########################################################
#

<a href="/people/{{ object.id }}/">{{ object.name }}</a>

#
# Code snippet 44 ########################################################
#

<a href="{{ object.get_absolute_url }}">{{ object.name }}</a>

#
# Code snippet 45 ########################################################
#

(r'^people/(\d+)/$', 'people.views.details'),

#
# Code snippet 46 ########################################################
#

@models.permalink
def get_absolute_url(self):
    return ('people.views.details', [str(self.id)])

#
# Code snippet 47 ########################################################
#

(r'/archive/(?P<year>\d{4})/(?P<month>\d{1,2})/(?P<day>\d{1,2})/$', archive_view)

#
# Code snippet 48 ########################################################
#

@models.permalink
def get_absolute_url(self):
    return ('archive_view', (), {
        'year': self.created.year,
        'month': self.created.month,
        'day': self.created.day})

#
# Code snippet 49 ########################################################
#

def my_custom_sql(self):
    from django.db import connection
    cursor = connection.cursor()
    cursor.execute("SELECT foo FROM bar WHERE baz = %s", [self.baz])
    row = cursor.fetchone()
    return row

#
# Code snippet 50 ########################################################
#

class Blog(models.Model):
    name = models.CharField(maxlength=100)
    tagline = models.TextField()

    def save(self):
        do_something()
        super(Blog, self).save() # Call the "real" save() method.
        do_something_else()

#
# Code snippet 51 ########################################################
#

class Blog(models.Model):
    name = models.CharField(maxlength=100)
    tagline = models.TextField()

    def save(self):
        if self.name == "Yoko Ono's blog":
            return # Yoko shall never have her own blog!
        else:
            super(Blog, self).save() # Call the "real" save() method

#
# Code snippet 52 ########################################################
#

class Admin:
    pass

#
# Code snippet 53 ########################################################
#

class CustomerOrder(models.Model):
    order_date = models.DateTimeField()
    ...

    class Admin:
        date_hierarchy = "order_date"

#
# Code snippet 54 ########################################################
#

class FlatPage(models.Model):
    ...

    class Admin:
        fields = (
            (None, {
                'fields': ('url', 'title', 'content', 'sites')
            }),
            ('Advanced options', {
                'classes': 'collapse',
                'fields' : ('enable_comments', 'registration_required', 'template_name')
            }),
        )

#
# Code snippet 55 ########################################################
#

'fields': (('first_name', 'last_name'), 'address', 'city', 'state'),

#
# Code snippet 56 ########################################################
#

'classes': 'wide extrapretty',

#
# Code snippet 57 ########################################################
#

class Person(models.Model):
    name = models.CharField(maxlength=50)
    birthday = models.DateField()

    class Admin:
        list_display = ('name', 'decade_born_in')

    def decade_born_in(self):
        return self.birthday.strftime('%Y')[:3] + "0's"
    decade_born_in.short_description = 'Birth decade'

#
# Code snippet 58 ########################################################
#

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    last_name = models.CharField(maxlength=50)
    color_code = models.CharField(maxlength=6)

    class Admin:
        list_display = ('first_name', 'last_name', 'colored_name')

    def colored_name(self):
        return '<span style="color: #%s;">%s %s</span>' % (self.color_code, self.first_name, self.last_name)
    colored_name.allow_tags = True

#
# Code snippet 59 ########################################################
#

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    birthday = models.DateField()

    class Admin:
        list_display = ('name', 'born_in_fifties')

    def born_in_fifties(self):
        return self.birthday.strftime('%Y')[:3] == 5
    born_in_fifties.boolean = True

#
# Code snippet 60 ########################################################
#

list_display = ('__str__', 'some_other_field')

#
# Code snippet 61 ########################################################
#

class Person(models.Model):
    first_name = models.CharField(maxlength=50)
    color_code = models.CharField(maxlength=6)

    class Admin:
        list_display = ('first_name', 'colored_first_name')

    def colored_first_name(self):
        return '<span style="color: #%s;">%s</span>' % (self.color_code, self.first_name)
    colored_first_name.allow_tags = True
    colored_first_name.admin_order_field = 'first_name'

#
# Code snippet 62 ########################################################
#

class Person(models.Model):
    ...

    class Admin:
        list_display = ('first_name', 'last_name', 'birthday')
        list_display_links = ('first_name', 'last_name')

#
# Code snippet 63 ########################################################
#

class User(models.Model):
    ...

    class Admin:
        list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff')
        list_filter = ('is_staff', 'is_superuser')

#
# Code snippet 64 ########################################################
#

class Employee(models.Model):
    department = models.ForeignKey(Department)
    ...

    class Admin:
        search_fields = ['department__name']

#
# Code snippet 65 ########################################################
#

WHERE (first_name ILIKE '%john%' OR last_name ILIKE '%john%')
AND (first_name ILIKE '%lennon%' OR last_name ILIKE '%lennon%')

#
# Code snippet 66 ########################################################
#

WHERE (first_name ILIKE 'john%' OR last_name ILIKE 'john%')
AND (first_name ILIKE 'lennon%' OR last_name ILIKE 'lennon%')

#
# Code snippet 67 ########################################################
#

WHERE (first_name ILIKE 'john' OR last_name ILIKE 'john')
AND (first_name ILIKE 'lennon' OR last_name ILIKE 'lennon')

