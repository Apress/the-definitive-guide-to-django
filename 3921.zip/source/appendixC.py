#
# Code snippet 1 #########################################################
#

from django.db import models

class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField()

    def __str__(self):
        return self.name

class Author(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()

    def __str__(self):
        return self.name

class Entry(models.Model):
    blog = models.ForeignKey(Blog)
    headline = models.CharField(max_length=255)
    body_text = models.TextField()
    pub_date = models.DateTimeField()
    authors = models.ManyToManyField(Author)

    def __str__(self):
        return self.headline

#
# Code snippet 2 #########################################################
#

>>> from mysite.blog.models import Blog
>>> b = Blog(name='Beatles Blog', tagline='All the latest Beatles news.')
>>> b.save()

#
# Code snippet 3 #########################################################
#

>>> b2 = Blog(name='Cheddar Talk', tagline='Thoughts on cheese.')
>>> b2.id     # Returns None, because b doesn't have an ID yet.
None

>>> b2.save()
>>> b2.id     # Returns the ID of your new object.
14

#
# Code snippet 4 #########################################################
#

>>> b3 = Blog(id=3, name='Cheddar Talk', tagline='Thoughts on cheese.')
>>> b3.id
3
>>> b3.save()
>>> b3.id
3

#
# Code snippet 5 #########################################################
#

>>> b4 = Blog(id=3, name='Not Cheddar', tagline='Anything but cheese.')
>>> b4.save()  # Overrides the previous blog with ID=3!

#
# Code snippet 6 #########################################################
#

>>> b5.name = 'New name'
>>> b5.save()

#
# Code snippet 7 #########################################################
#

>>> joe = Author.objects.create(name="Joe")
>>> entry.author = joe
>>> entry.save()

#
# Code snippet 8 #########################################################
#

>>> blogs = Blog.objects.filter(author__name__contains="Joe")

#
# Code snippet 9 #########################################################
#

>>> Blog.objects
<django.db.models.manager.Manager object at 0x137d00d>

#
# Code snippet 10 #########################################################
#

>>> b = Blog(name='Foo', tagline='Bar')
>>> b.objects
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
AttributeError: Manager isn't accessible via Blog instances.

#
# Code snippet 11 ########################################################
#

print [e.headline for e in Entry.objects.all()]
print [e.pub_date for e in Entry.objects.all()]

#
# Code snippet 12 ########################################################
#

queryset = Poll.objects.all()
print [p.headline for p in queryset] # Evaluate the query set.
print [p.pub_date for p in queryset] # Reuse the cache from the evaluation.

#
# Code snippet 13 ########################################################
#

>>> Entry.objects.all()

#
# Code snippet 14 ########################################################
#

>>> y2006 = Entry.objects.filter(pub_date__year=2006)
>>> not2006 = Entry.objects.exclude(pub_date__year=2006)

#
# Code snippet 15 ########################################################
#

>>> qs = Entry.objects.filter(headline__startswith='What')
>>> qs = qs..exclude(pub_date__gte=datetime.datetime.now())
>>> qs = qs.filter(pub_date__gte=datetime.datetime(2005, 1, 1))

#
# Code snippet 16 ########################################################
#

qs = Entry.objects.filter(pub_date__year=2006)
qs = qs.filter(headline__icontains="bill")
for e in qs:
    print e.headline

#
# Code snippet 17 ########################################################
#

>>> entry_list = list(Entry.objects.all())

#
# Code snippet 18 ########################################################
#

q1 = Entry.objects.filter(headline__startswith="What")
q2 = q1.exclude(pub_date__gte=datetime.now())
q3 = q1.filter(pub_date__gte=datetime.now())

#
# Code snippet 19 ########################################################
#

>>> Entry.objects.all()[:5]

#
# Code snippet 20 ########################################################
#

>>> Entry.objects.all()[5:10]

#
# Code snippet 21 ########################################################
#

>>> Entry.objects.all()[:10:2]

#
# Code snippet 22 ########################################################
#

>>> Entry.objects.order_by('headline')[0]

#
# Code snippet 23 ########################################################
#

>>> Entry.objects.order_by('headline')[0:1].get()

#
# Code snippet 24 ########################################################
#

>> Entry.objects.filter(pub_date__year=2005).order_by('-pub_date', 'headline')

#
# Code snippet 25 ########################################################
#

>>> Entry.objects.order_by('?')

#
# Code snippet 26 ########################################################
#

# This list contains a Blog object.
>>> Blog.objects.filter(name__startswith='Beatles')
[Beatles Blog]

# This list contains a dictionary.
>>> Blog.objects.filter(name__startswith='Beatles').values()
[{'id': 1, 'name': 'Beatles Blog', 'tagline': 'All the latest Beatles news.'}]

#
# Code snippet 27 ########################################################
#

>>> Blog.objects.values()
[{'id': 1, 'name': 'Beatles Blog', 'tagline': 'All the latest Beatles news.'}],
>>> Blog.objects.values('id', 'name')
[{'id': 1, 'name': 'Beatles Blog'}]

#
# Code snippet 28 ########################################################
#

>>> Entry.objects.dates('pub_date', 'year')
[datetime.datetime(2005, 1, 1)]

>>> Entry.objects.dates('pub_date', 'month')
[datetime.datetime(2005, 2, 1), datetime.datetime(2005, 3, 1)]

>>> Entry.objects.dates('pub_date', 'day')
[datetime.datetime(2005, 2, 20), datetime.datetime(2005, 3, 20)]

>>> Entry.objects.dates('pub_date', 'day', order='DESC')
[datetime.datetime(2005, 3, 20), datetime.datetime(2005, 2, 20)]

>>> Entry.objects.filter(headline__contains='Lennon').dates('pub_date', 'day')
[datetime.datetime(2005, 3, 20)]

#
# Code snippet 29 ########################################################
#

# Hits the database.
>>> e = Entry.objects.get(id=5)

# Hits the database again to get the related Blog object.
>>> b = e.blog

#
# Code snippet 30 ########################################################
#

# Hits the database.
>>> e = Entry.objects.select_related().get(id=5)

# Doesn't hit the database, because e.blog has been prepopulated
# in the previous query.
>>> b = e.blog

#
# Code snippet 31 ########################################################
#

class City(models.Model):
    # ...

class Person(models.Model):
    # ...
    hometown = models.ForeignKey(City)

class Book(models.Model):
    # ...
    author = models.ForeignKey(Person)

#
# Code snippet 32 ########################################################
#

>>> b = Book.objects.select_related().get(id=4)
>>> p = b.author         # Doesn't hit the database.
>>> c = p.hometown       # Doesn't hit the database.

>>> b = Book.objects.get(id=4) # No select_related() in this example.
>>> p = b.author         # Hits the database.
>>> c = p.hometown       # Hits the database.

#
# Code snippet 33 ########################################################
#

>>> Entry.objects.extra(select={'is_recent': "pub_date > '2006-01-01'"})

#
# Code snippet 34 ########################################################
#

>>> subq = 'SELECT COUNT(*) FROM blog_entry WHERE blog_entry.blog_id = blog_blog.id'
>>> Blog.objects.extra(select={'entry_count': subq})

#
# Code snippet 35 ########################################################
#

>>> Entry.objects.extra(where=['id IN (3, 4, 5, 20)'])

#
# Code snippet 36 ########################################################
#

>>> Entry.objects.extra(where=['headline=%s'], params=['Lennon'])

#
# Code snippet 37 ########################################################
#

Entry.objects.extra(where=["headline='%s'" % name])

#
# Code snippet 38 ########################################################
#

Entry.objects.extra(where=['headline=%s'], params=[name])

#
# Code snippet 39 ########################################################
#

>>> Entry.objects.get(id='foo') # raises Entry.DoesNotExist

#
# Code snippet 40 ########################################################
#

>>> from django.core.exceptions import ObjectDoesNotExist
>>> try:
...     e = Entry.objects.get(id=3)
...     b = Blog.objects.get(id=1)
... except ObjectDoesNotExist:
...     print "Either the entry or blog doesn't exist."

#
# Code snippet 41 ########################################################
#

>>> p = Person(first_name="Bruce", last_name="Springsteen")
>>> p.save()

#
# Code snippet 42 ########################################################
#

>>> p = Person.objects.create(first_name="Bruce", last_name="Springsteen")

#
# Code snippet 43 ########################################################
#

try:
    obj = Person.objects.get(first_name='John', last_name='Lennon')
except Person.DoesNotExist:
    obj = Person(first_name='John', last_name='Lennon', birthday=date(1940, 10, 9))
    obj.save()

#
# Code snippet 44 ########################################################
#

obj, created = Person.objects.get_or_create(
    first_name = 'John',
    last_name  = 'Lennon',
    defaults   = {'birthday': date(1940, 10, 9)}
)

#
# Code snippet 45 ########################################################
#

defaults = kwargs.pop('defaults', {})
params = dict([(k, v) for k, v in kwargs.items() if '__' not in k])
params.update(defaults)
obj = self.model(**params)
obj.save()

#
# Code snippet 46 ########################################################
#

Foo.objects.get_or_create(
    defaults__exact = 'bar',
    defaults={'defaults': 'baz'}
)

#
# Code snippet 47 ########################################################
#

# Returns the total number of entries in the database.
>>> Entry.objects.count()
4

# Returns the number of entries whose headline contains 'Lennon'
>>> Entry.objects.filter(headline__contains='Lennon').count()
1

#
# Code snippet 48 ########################################################
#

>>> Blog.objects.in_bulk([1])
{1: Beatles Blog}
>>> Blog.objects.in_bulk([1, 2])
{1: Beatles Blog, 2: Cheddar Talk}
>>> Blog.objects.in_bulk([])
{}

#
# Code snippet 49 ########################################################
#

>>> Entry.objects.latest('pub_date')

#
# Code snippet 50 ########################################################
#

>>> Entry.objects.filter(pub_date__lte='2006-01-01')

#
# Code snippet 51 ########################################################
#

SELECT * FROM blog_entry WHERE pub_date <= '2006-01-01';

#
# Code snippet 52 ########################################################
#

>>> Entry.objects.get(headline__exact="Man bites dog")

#
# Code snippet 53 ########################################################
#

>>> Blog.objects.get(id__exact=14) # Explicit form
>>> Blog.objects.get(id=14) # __exact is implied

#
# Code snippet 54 ########################################################
#

>>> Blog.objects.get(name__iexact='beatles blog')

#
# Code snippet 55 ########################################################
#

Entry.objects.get(headline__contains='Lennon')

#
# Code snippet 56 ########################################################
#

Entry.objects.filter(headline__contains='%')

#
# Code snippet 57 ########################################################
#

SELECT ... WHERE headline LIKE '%\%%';

#
# Code snippet 58 ########################################################
#

>>> Entry.objects.get(headline__icontains='Lennon')

#
# Code snippet 59 ########################################################
#

>>> Entry.objects.filter(id__gt=4)
>>> Entry.objects.filter(id__lt=15)
>>> Entry.objects.filter(id__gte=0)

#
# Code snippet 60 ########################################################
#

Entry.objects.filter(id__in=[1, 3, 4])

#
# Code snippet 61 ########################################################
#

>>> Entry.objects.filter(headline__startswith='Will')

#
# Code snippet 62 ########################################################
#

>>> Entry.objects.filter(headline__istartswith='will')

#
# Code snippet 63 ########################################################
#

>>> Entry.objects.filter(headline__endswith='cats')
>>> Entry.objects.filter(headline__iendswith='cats')

#
# Code snippet 64 ########################################################
#

>>> start_date = datetime.date(2005, 1, 1)
>>> end_date = datetime.date(2005, 3, 31)
>>> Entry.objects.filter(pub_date__range=(start_date, end_date))

#
# Code snippet 65 ########################################################
#

# Year lookup
>>>Entry.objects.filter(pub_date__year=2005)

# Month lookup -- takes integers
>>> Entry.objects.filter(pub_date__month=12)

# Day lookup
>>> Entry.objects.filter(pub_date__day=3)

# Combination: return all entries on Christmas of any year
>>> Entry.objects.filter(pub_date__month=12, pub_date_day=25)

#
# Code snippet 66 ########################################################
#

>>> Entry.objects.filter(pub_date__isnull=True)

#
# Code snippet 67 ########################################################
#

>>> Blog.objects.get(id__exact=14) # Explicit form
>>> Blog.objects.get(id=14) # __exact is implied
>>> Blog.objects.get(pk=14) # pk implies id__exact

#
# Code snippet 68 ########################################################
#

# Get blogs entries  with id 1, 4, and 7
>>> Blog.objects.filter(pk__in=[1,4,7])

# Get all blog entries with id > 14
>>> Blog.objects.filter(pk__gt=14)

#
# Code snippet 69 ########################################################
#

>>> Entry.objects.filter(blog__id__exact=3) # Explicit form
>>> Entry.objects.filter(blog__id=3) # __exact is implied
>>> Entry.objects.filter(blog__pk=3) # __pk implies __id__exact

#
# Code snippet 70 ########################################################
#

Q(question__startswith='What')

#
# Code snippet 71 ########################################################
#

Q(question__startswith='Who') | Q(question__startswith='What')

#
# Code snippet 72 ########################################################
#

WHERE question LIKE 'Who%' OR question LIKE 'What%'

#
# Code snippet 73 ########################################################
#

Poll.objects.get(
    Q(question__startswith='Who'),
    Q(pub_date=date(2005, 5, 2)) | Q(pub_date=date(2005, 5, 6))
)

#
# Code snippet 74 ########################################################
#

SELECT * from polls WHERE question LIKE 'Who%'
    AND (pub_date = '2005-05-02' OR pub_date = '2005-05-06')

#
# Code snippet 75 ########################################################
#

Poll.objects.get(
    Q(pub_date=date(2005, 5, 2)) | Q(pub_date=date(2005, 5, 6)),
    question__startswith='Who')

#
# Code snippet 76 ########################################################
#

# INVALID QUERY
Poll.objects.get(
    question__startswith='Who',
    Q(pub_date=date(2005, 5, 2)) | Q(pub_date=date(2005, 5, 6)))

#
# Code snippet 77 ########################################################
#

>>> Entry.objects.filter(blog__name__exact='Beatles Blog')

#
# Code snippet 78 ########################################################
#

>>> Blog.objects.filter(entry__headline__contains='Lennon')

#
# Code snippet 79 ########################################################
#

e = Entry.objects.get(id=2)
e.blog # Returns the related Blog object.

#
# Code snippet 80 ########################################################
#

e = Entry.objects.get(id=2)
e.blog = some_blog
e.save()

#
# Code snippet 81 ########################################################
#

e = Entry.objects.get(id=2)
e.blog = None
e.save() # "UPDATE blog_entry SET blog_id = NULL ...;"

#
# Code snippet 82 ########################################################
#

e = Entry.objects.get(id=2)
print e.blog  # Hits the database to retrieve the associated Blog.
print e.blog  # Doesn't hit the database; uses cached version.

#
# Code snippet 83 ########################################################
#

e = Entry.objects.select_related().get(id=2)
print e.blog  # Doesn't hit the database; uses cached version.
print e.blog  # Doesn't hit the database; uses cached version.

#
# Code snippet 84 ########################################################
#

b = Blog.objects.get(id=1)
b.entry_set.all() # Returns all Entry objects related to Blog.

# b.entry_set is a Manager that returns QuerySets.
b.entry_set.filter(headline__contains='Lennon')
b.entry_set.count()

#
# Code snippet 85 ########################################################
#

b = Blog.objects.get(id=1)
b.entries.all() # Returns all Entry objects related to Blog.

# b.entries is a Manager that returns QuerySets.
b.entries.filter(headline__contains='Lennon')
b.entries.count()

#
# Code snippet 86 ########################################################
#

Blog.entry_set # Raises AttributeError: "Manager must be accessed via instance".

#
# Code snippet 87 ########################################################
#

b = Blog.objects.get(id=1)
e = Entry.objects.get(id=234)
b.entry_set.add(e) # Associates Entry e with Blog b.

#
# Code snippet 88 ########################################################
#

b = Blog.objects.get(id=1)
e = b.entry_set.create(headline='Hello', body_text='Hi', pub_date=datetime.date(2005, 1, 1))
# No need to call e.save() at this point -- it's already been saved.

#
# Code snippet 89 ########################################################
#

b = Blog.objects.get(id=1)
e = Entry(blog=b, headline='Hello', body_text='Hi', pub_date=datetime.date(2005, 1, 1))
e.save()

#
# Code snippet 90 ########################################################
#

b = Blog.objects.get(id=1)
e = Entry.objects.get(id=234)
b.entry_set.remove(e) # Disassociates Entry e from Blog b.

#
# Code snippet 91 ########################################################
#

b = Blog.objects.get(id=1)
b.entry_set.clear()

#
# Code snippet 92 ########################################################
#

b = Blog.objects.get(id=1)
b.entry_set = [e1, e2]

#
# Code snippet 93 ########################################################
#

e = Entry.objects.get(id=3)
e.authors.all() # Returns all Author objects for this Entry.
e.authors.count()
e.authors.filter(name__contains='John')

a = Author.objects.get(id=5)
a.entry_set.all() # Returns all Entry objects for this Author.

#
# Code snippet 94 ########################################################
#

Entry.objects.filter(blog=b) # Query using object instance
Entry.objects.filter(blog=b.id) # Query using id from instance
Entry.objects.filter(blog=5) # Query using id directly

#
# Code snippet 95 ########################################################
#

e.delete()

#
# Code snippet 96 ########################################################
#

Entry.objects.filter(pub_date__year=2005).delete()

#
# Code snippet 97 ########################################################
#

b = Blog.objects.get(pk=1)
# This will delete the Blog and all of its Entry objects.
b.delete()

#
# Code snippet 98 ########################################################
#

Entry.objects.all().delete()

#
# Code snippet 99 ########################################################
#

GENDER_CHOICES = (
    ('M', 'Male'),
    ('F', 'Female'),
)
class Person(models.Model):
    name = models.CharField(max_length=20)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)

#
# Code snippet 100 ########################################################
#

>>> p = Person(name='John', gender='M')
>>> p.save()
>>> p.gender
'M'
>>> p.get_gender_display()
'Male'

#
# Code snippet 101 #######################################################
#

# Get the Entry with a primary key of 3
e = get_object_or_404(Entry, pk=3)

#
# Code snippet 102 #######################################################
#

# Get the author of blog instance e with a name of 'Fred'
a = get_object_or_404(e.authors, name='Fred')

# Use a custom manager 'recent_entries' in the search for an
# entry with a primary key of 3
e = get_object_or_404(Entry.recent_entries, pk=3)

