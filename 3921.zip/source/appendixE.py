#
# Code snippet 1 #########################################################
#

DEBUG = False
DEFAULT_FROM_EMAIL = 'webmaster@example.com'
TEMPLATE_DIRS = ('/home/templates/mike', '/home/templates/john')

#
# Code snippet 2 #########################################################
#

MY_SETTING = [str(i) for i in range(30)]

#
# Code snippet 3 #########################################################
#

from django.conf import settings

if settings.DEBUG:
    # Do something

#
# Code snippet 4 #########################################################
#

from django.conf.settings import DEBUG  # This won't work.

#
# Code snippet 5 #########################################################
#

from django.conf import settings

settings.DEBUG = True   # Don't do this!

#
# Code snippet 6 #########################################################
#

export DJANGO_SETTINGS_MODULE=mysite.settings
django-admin.py runserver

#
# Code snippet 7 #########################################################
#

set DJANGO_SETTINGS_MODULE=mysite.settings
django-admin.py runserver

#
# Code snippet 8 #########################################################
#

django-admin.py runserver --settings=mysite.settings

#
# Code snippet 9 #########################################################
#

<Location "/mysite/">
    SetHandler python-program
    PythonHandler django.core.handlers.modpython
    SetEnv DJANGO_SETTINGS_MODULE mysite.settings
</Location>

#
# Code snippet 10 #########################################################
#

from django.conf import settings

settings.configure(
    DEBUG = True,
    TEMPLATE_DEBUG = True,
    TEMPLATE_DIRS = [
        '/home/web-apps/myapp',
        '/home/web-apps/base',
    ]
)

#
# Code snippet 11 ########################################################
#

from django.conf import settings
from myapp import myapp_defaults

settings.configure(default_settings=myapp_defaults, DEBUG=True)

#
# Code snippet 12 ########################################################
#

settings.configure(myapp_defaults, DEBUG = True)

#
# Code snippet 13 ########################################################
#

ABSOLUTE_URL_OVERRIDES = {
    'blogs.weblog': lambda o: "/blogs/%s/" % o.slug,
    'news.story': lambda o: "/stories/%s/%s/" % (o.pub_year, o.slug),
}

#
# Code snippet 14 ########################################################
#

(('John', 'john@example.com'), ('Mary', 'mary@example.com'))

#
# Code snippet 15 ########################################################
#

DATABASE_HOST = '/var/run/mysql'

#
# Code snippet 16 ########################################################
#

gettext = lambda s: s

LANGUAGES = (
    ('de', gettext('German')),
    ('en', gettext('English')),
)

#
# Code snippet 17 ########################################################
#

("django.contrib.sessions.middleware.SessionMiddleware",
 "django.contrib.auth.middleware.AuthenticationMiddleware",
 "django.middleware.common.CommonMiddleware",
 "django.middleware.doc.XViewMiddleware")

#
# Code snippet 18 ########################################################
#

("django.core.context_processors.auth",
"django.core.context_processors.debug",
"django.core.context_processors.i18n")

