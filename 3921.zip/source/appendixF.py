#
# Code snippet 1 #########################################################
#

{% for o in some_list %}
    <tr class="{% cycle row1,row2 %}">
        ...
    </tr>
{% endfor %}

#
# Code snippet 2 #########################################################
#

<tr class="{% cycle row1,row2,row3 as rowcolors %}">...</tr>
<tr class="{% cycle rowcolors %}">...</tr>
<tr class="{% cycle rowcolors %}">...</tr>

#
# Code snippet 3 #########################################################
#

{% filter escape|lower %}
    This text will be HTML-escaped, and will appear in all lowercase.
{% endfilter %}

#
# Code snippet 4 #########################################################
#

{% firstof var1 var2 var3 %}

#
# Code snippet 5 #########################################################
#

{% if var1 %}
    {{ var1 }}
{% else %}{% if var2 %}
    {{ var2 }}
{% else %}{% if var3 %}
    {{ var3 }}
{% endif %}{% endif %}{% endif %}

#
# Code snippet 6 #########################################################
#

<ul>
{% for athlete in athlete_list %}
    <li>{{ athlete.name }}</li>
{% endfor %}
</ul>

#
# Code snippet 7 #########################################################
#

{% if athlete_list %}
    Number of athletes: {{ athlete_list|length }}
{% else %}
    No athletes.
{% endif %}

#
# Code snippet 8 #########################################################
#

{% if athlete_list and coach_list %}
    Both athletes and coaches are available.
{% endif %}

{% if not athlete_list %}
    There are no athletes.
{% endif %}

{% if athlete_list or coach_list %}
    There are some athletes or some coaches.
{% endif %}

{% if not athlete_list or coach_list %}
    There are no athletes or there are some coaches (OK, so
    writing English translations of Boolean logic sounds
    stupid; it's not our fault).
{% endif %}

{% if athlete_list and not coach_list %}
    There are some athletes and absolutely no coaches.
{% endif %}

#
# Code snippet 9 #########################################################
#

{% if athlete_list and coach_list or cheerleader_list %}

#
# Code snippet 10 #########################################################
#

{% if athlete_list %}
    {% if coach_list or cheerleader_list %}
        We have athletes, and either coaches or cheerleaders!
    {% endif %}
{% endif %}

#
# Code snippet 11 ########################################################
#

{% if athlete_list or coach_list or parent_list or teacher_list %}

#
# Code snippet 12 ########################################################
#

<h1>Archive for {{ year }}</h1>

{% for date in days %}
    {% ifchanged %}<h3>{{ date|date:"F" }}</h3>{% endifchanged %}
    <a href="{{ date|date:"M/d"|lower }}/">{{ date|date:"j" }}</a>
{% endfor %}

#
# Code snippet 13 ########################################################
#

{% for date in days %}
    {% ifchanged date.date %} {{ date.date }} {% endifchanged %}
    {% ifchanged date.hour date.date %}
        {{ date.hour }}
    {% endifchanged %}
{% endfor %}

#
# Code snippet 14 ########################################################
#

{% ifequal user.id comment.user_id %}
    ...
{% endifequal %}

#
# Code snippet 15 ########################################################
#

{% ifequal user.username "adrian" %}
    ...
{% endifequal %}

#
# Code snippet 16 ########################################################
#

{% include "foo/bar.html" %}

#
# Code snippet 17 ########################################################
#

{% include template_name %}

#
# Code snippet 18 ########################################################
#

It is {% now "jS F Y H:i" %}

#
# Code snippet 19 ########################################################
#

It is the {% now "jS o\f F" %}

#
# Code snippet 20 ########################################################
#

* Male:
    * George Bush
    * Bill Clinton
* Female:
    * Margaret Thatcher
    * Condoleezza Rice
* Unknown:
    * Pat Smith

#
# Code snippet 21 ########################################################
#

{% regroup people by gender as grouped %}
<ul>
{% for group in grouped %}
    <li>{{ group.grouper }}
    <ul>
        {% for item in group.list %}
        <li>{{ item }}</li>
        {% endfor %}
    </ul>
    </li>
{% endfor %}
</ul>

#
# Code snippet 22 ########################################################
#

{% regroup people|dictsort:"gender" by gender as grouped %}

#
# Code snippet 23 ########################################################
#

{% spaceless %}
    <p>
        <a href="foo/">Foo</a>
    </p>
{% endspaceless %}

#
# Code snippet 24 ########################################################
#

<p><a href="foo/">Foo</a></p>

#
# Code snippet 25 ########################################################
#

{% spaceless %}
    <strong>
        Hello
    </strong>
{% endspaceless %}

#
# Code snippet 26 ########################################################
#

{% ssi /home/html/ljworld.com/includes/right_generic.html %}

#
# Code snippet 27 ########################################################
#

{% ssi /home/html/ljworld.com/includes/right_generic.html parsed %}

#
# Code snippet 28 ########################################################
#

{% url path.to.some_view arg1,arg2,name1=value1 %}

#
# Code snippet 29 ########################################################
#

('^client/(\d+)/$', 'app_name.client')

#
# Code snippet 30 ########################################################
#

('^clients/', include('project_name.app_name.urls'))

#
# Code snippet 31 ########################################################
#

{% url app_name.client client.id %}

#
# Code snippet 32 ########################################################
#

<img src="bar.gif" height="10" width="{% widthratio this_value max_value 100 %}" />

#
# Code snippet 33 ########################################################
#

{{ value|add:"5" }}

#
# Code snippet 34 ########################################################
#

{{ string|addslashes }}

#
# Code snippet 35 ########################################################
#

{{ string|capfirst }}

#
# Code snippet 36 ########################################################
#

{{ string|center:"50" }}

#
# Code snippet 37 ########################################################
#

{{ string|cut:"spam" }}

#
# Code snippet 38 ########################################################
#

{{ value|date:"F j, Y" }}

#
# Code snippet 39 ########################################################
#

{{ value|default:"(N/A)" }}

#
# Code snippet 40 ########################################################
#

{{ value|default_if_none:"(N/A)" }}

#
# Code snippet 41 ########################################################
#

{{ list|dictsort:"foo" }}

#
# Code snippet 42 ########################################################
#

{{ list|dictsortreversed:"foo" }}

#
# Code snippet 43 ########################################################
#

{% if value|divisibleby:"2" %}
    Even!
{% else %}
    Odd!
{% else %}

#
# Code snippet 44 ########################################################
#

{{ string|escape }}

#
# Code snippet 45 ########################################################
#

{{ value|filesizeformat }}

#
# Code snippet 46 ########################################################
#

{{ list|first }}

#
# Code snippet 47 ########################################################
#

{{ string|fix_ampersands }}

#
# Code snippet 48 ########################################################
#

{{ value|floatformat }}
{{ value|floatformat:"2" }}

#
# Code snippet 49 ########################################################
#

{{ value|get_digit:"1" }}

#
# Code snippet 50 ########################################################
#

{{ list|join:", " }}

#
# Code snippet 51 ########################################################
#

{{ list|length }}

#
# Code snippet 52 ########################################################
#

{% if list|length_is:"3" %}
    ...
{% endif %}

#
# Code snippet 53 ########################################################
#

{{ string|linebreaks }}

#
# Code snippet 54 ########################################################
#

{{ string|linebreaksbr }}

#
# Code snippet 55 ########################################################
#

{{ string|linenumbers }}

#
# Code snippet 56 ########################################################
#

{{ string|ljust:"50" }}

#
# Code snippet 57 ########################################################
#

{{ string|lower }}

#
# Code snippet 58 ########################################################
#

{% for i in number|make_list %}
    ...
{% endfor %}

#
# Code snippet 59 ########################################################
#

{{ string|phone2numeric }}

#
# Code snippet 60 ########################################################
#

The list has {{ list|length }} item{{ list|pluralize }}.

#
# Code snippet 61 ########################################################
#

You have {{ num_messages }} message{{ num_messages|pluralize }}.

#
# Code snippet 62 ########################################################
#

You have {{ num_walruses }} walrus{{ num_walrus|pluralize:"es" }}.

#
# Code snippet 63 ########################################################
#

You have {{ num_cherries }} cherr{{ num_cherries|pluralize:"y,ies" }}.

#
# Code snippet 64 ########################################################
#

{{ object|pprint }}

#
# Code snippet 65 ########################################################
#

{{ list|random }}

#
# Code snippet 66 ########################################################
#

{{ string|removetags:"br p div" }}

#
# Code snippet 67 ########################################################
#

{{ string|rjust:"50" }}

#
# Code snippet 68 ########################################################
#

{{ some_list|slice:":2" }}

#
# Code snippet 69 ########################################################
#

{{ string|slugify }}

#
# Code snippet 70 ########################################################
#

{{ number|stringformat:"02i" }}

#
# Code snippet 71 ########################################################
#

{{ string|striptags }}

#
# Code snippet 72 ########################################################
#

{{ value|time:"P" }}

#
# Code snippet 73 ########################################################
#

{{ datetime|timesince }}
{{ datetime|timesince:"other_datetime" }}

#
# Code snippet 74 ########################################################
#

{{ datetime|timeuntil }}
{{ datetime|timeuntil:"other_datetime" }}

#
# Code snippet 75 ########################################################
#

{{ string|titlecase }}

#
# Code snippet 76 ########################################################
#

{{ string|truncatewords:"15" }}

#
# Code snippet 77 ########################################################
#

{{ string|truncatewords_html:"15" }}

#
# Code snippet 78 ########################################################
#

<ul>
    {{ list|unordered_list }}
</ul>

#
# Code snippet 79 ########################################################
#

<li>States
<ul>
        <li>Kansas
        <ul>
                <li>Lawrence</li>
                <li>Topeka</li>
        </ul>
        </li>
        <li>Illinois</li>
</ul>
</li>

#
# Code snippet 80 ########################################################
#

{{ string|upper }}

#
# Code snippet 81 ########################################################
#

<a href="{{ link|urlencode }}">linkage</a>

#
# Code snippet 82 ########################################################
#

{{ string|urlize }}

#
# Code snippet 83 ########################################################
#

{{ string|urlizetrunc:"30" }}

#
# Code snippet 84 ########################################################
#

{{ string|wordcount }}

#
# Code snippet 85 ########################################################
#

{{ string|wordwrap:"75" }}

#
# Code snippet 86 ########################################################
#

{{ boolean|yesno:"Yes,No,Perhaps" }}

