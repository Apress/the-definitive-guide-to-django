#
# Code snippet 1 #########################################################
#

django-admin.py action [options]

#
# Code snippet 2 #########################################################
#

manage.py action [options]

#
# Code snippet 3 #########################################################
#

django-admin.py loaddata mydata.json

#
# Code snippet 4 #########################################################
#

django-admin.py loaddata mydata

#
# Code snippet 5 #########################################################
#

django-admin.py loaddata foo/bar/mydata.json

#
# Code snippet 6 #########################################################
#

django-admin.py runserver 7000

#
# Code snippet 7 #########################################################
#

django-admin.py runserver 1.2.3.4:7000

#
# Code snippet 8 #########################################################
#

django-admin.py runserver --noreload

#
# Code snippet 9 #########################################################
#

django-admin.py shell --plain

#
# Code snippet 10 #########################################################
#

django-admin.py syncdb --settings=mysite.settings

#
# Code snippet 11 ########################################################
#

django-admin.py syncdb --pythonpath='/home/djangoprojects/myproject'

#
# Code snippet 12 ########################################################
#

django-admin.py dumpdata --format=xml

#
# Code snippet 13 ########################################################
#

django-admin.py dumpdata --indent=4

#
# Code snippet 14 ########################################################
#

0.9.1
0.9.1 (SVN)

#
# Code snippet 15 ########################################################
#

django-admin.py syncdb --verbosity=2

#
# Code snippet 16 ########################################################
#

django-admin.py --adminmedia=/tmp/new-admin-style/

