#
# Code snippet 1 #########################################################
#

if request.method == 'GET':
    do_something()
elif request.method == 'POST':
    do_something_else()

#
# Code snippet 2 #########################################################
#

if request.user.is_authenticated():
    # Do something for logged-in users.
else:
    # Do something for anonymous users.

#
# Code snippet 3 #########################################################
#

>>> q = QueryDict('a=1')
>>> q = q.copy() # to make it mutable
>>> q.update({'a': '2'})
>>> q.getlist('a')
['1', '2']
>>> q['a'] # returns the last
['2']

#
# Code snippet 4 #########################################################
#

>>> q = QueryDict('a=1&a=2&a=3')
>>> q.items()
[('a', '3')]

#
# Code snippet 5 #########################################################
#

>>> q = QueryDict('a=1&a=2&a=3')
>>> q.lists()
[('a', ['1', '2', '3'])]

#
# Code snippet 6 #########################################################
#

<form action="/foo/bar/" method="post">
<input type="text" name="your_name" />
<select multiple="multiple" name="bands">
    <option value="beatles">The Beatles</option>
    <option value="who">The Who</option>
    <option value="zombies">The Zombies</option>
</select>
<input type="submit" />
</form>

#
# Code snippet 7 #########################################################
#

>>> request.GET
{}
>>> request.POST
{'your_name': ['John Smith'], 'bands': ['beatles', 'zombies']}
>>> request.POST['your_name']
'John Smith'
>>> request.POST['bands']
'zombies'
>>> request.POST.getlist('bands')
['beatles', 'zombies']
>>> request.POST.get('your_name', 'Adrian')
'John Smith'
>>> request.POST.get('nonexistent_field', 'Nowhere Man')
'Nowhere Man'

#
# Code snippet 8 #########################################################
#

>>> response = HttpResponse("Here's the text of the Web page.")
>>> response = HttpResponse("Text only, please.", mimetype="text/plain")

#
# Code snippet 9 #########################################################
#

>>> response = HttpResponse()
>>> response.write("<p>Here's the text of the Web page.</p>")
>>> response.write("<p>Here's another paragraph.</p>")

#
# Code snippet 10 #########################################################
#

>>> response = HttpResponse()
>>> response['X-DJANGO'] = "It's the best."
>>> del response['X-PHP']
>>> response['X-DJANGO']
"It's the best."

#
# Code snippet 11 ########################################################
#

def my_view(request):
    # ...
    if foo:
        return HttpResponseNotFound('<h1>Page not found</h1>')
    else:
        return HttpResponse('<h1>Page was found</h1>')

#
# Code snippet 12 ########################################################
#

return HttpResponseNotFound('<h1>Page not found</h1>')

#
# Code snippet 13 ########################################################
#

from django.http import Http404

def detail(request, poll_id):
    try:
        p = Poll.objects.get(pk=poll_id)
    except Poll.DoesNotExist:
        raise Http404
    return render_to_response('polls/detail.html', {'poll': p})

#
# Code snippet 14 ########################################################
#

from django.conf.urls.defaults import *

urlpatterns = patterns('',
    ...
)

handler404 = 'mysite.views.my_custom_404_view'

#
# Code snippet 15 ########################################################
#

from django.conf.urls.defaults import *

#
# Code snippet 16 ########################################################
#

from django.conf.urls.defaults import *

urlpatterns = patterns('',
    ...
)

handler500 = 'mysite.views.my_custom_error_view'

