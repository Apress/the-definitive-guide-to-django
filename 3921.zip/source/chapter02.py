#
# Code snippet 1 #########################################################
#

Python 2.4.1 (#2, Mar 31 2005, 00:05:10)
[GCC 3.3 20030304 (Apple Computer, Inc. build 1666)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>>

#
# Code snippet 2 #########################################################
#

mysite/
    __init__.py
    manage.py
    settings.py
    urls.py

#
# Code snippet 3 #########################################################
#

Validating models...
0 errors found.

Django version 1.0, using settings 'mysite.settings'
Development server is running at http://127.0.0.1:8000/
Quit the server with CONTROL-C.

#
# Code snippet 4 #########################################################
#

python manage.py runserver 8080

#
# Code snippet 5 #########################################################
#

python manage.py runserver 0.0.0.0:8080

