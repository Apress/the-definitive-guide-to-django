#
# Code snippet 1 #########################################################
#

given a URL, try finding that page in the cache
if the page is in the cache:
    return the cached page
else:
    generate the page
    save the generated page in the cache (for next time)
    return the generated page

#
# Code snippet 2 #########################################################
#

CACHE_BACKEND = 'memcached://127.0.0.1:11211/'

#
# Code snippet 3 #########################################################
#

CACHE_BACKEND = 'memcached://172.19.26.240:11211;172.19.26.242:11211/'

#
# Code snippet 4 #########################################################
#

CACHE_BACKEND = 'memcached://172.19.26.240:11211;172.19.26.242:11212;172.19.26.244:11213/'

#
# Code snippet 5 #########################################################
#

python manage.py createcachetable [cache_table_name]

#
# Code snippet 6 #########################################################
#

CACHE_BACKEND = 'db://my_cache_table'

#
# Code snippet 7 #########################################################
#

CACHE_BACKEND = 'file:///var/tmp/django_cache'

#
# Code snippet 8 #########################################################
#

CACHE_BACKEND = 'locmem:///'

#
# Code snippet 9 #########################################################
#

CACHE_BACKEND = 'simple:///'

#
# Code snippet 10 #########################################################
#

CACHE_BACKEND = 'dummy:///'

#
# Code snippet 11 ########################################################
#

CACHE_BACKEND = "locmem:///?timeout=60"

#
# Code snippet 12 ########################################################
#

CACHE_BACKEND = "locmem:///?timeout=30&max_entries=400"

#
# Code snippet 13 ########################################################
#

MIDDLEWARE_CLASSES = (
    'django.middleware.cache.CacheMiddleware',
    'django.middleware.common.CommonMiddleware',
)

#
# Code snippet 14 ########################################################
#

from django.views.decorators.cache import cache_page

def my_view(request, param):
    # ...
my_view = cache_page(my_view, 60 * 15)

#
# Code snippet 15 ########################################################
#

from django.views.decorators.cache import cache_page

@cache_page(60 * 15)
def my_view(request, param):
    # ...

#
# Code snippet 16 ########################################################
#

urlpatterns = ('',
    (r'^foo/(\d{1,2})/$', my_view),
)

#
# Code snippet 17 ########################################################
#

urlpatterns = ('',
    (r'^foo/(\d{1,2})/$', my_view),
)

#
# Code snippet 18 ########################################################
#

from django.views.decorators.cache import cache_page

urlpatterns = ('',
    (r'^foo/(\d{1,2})/$', cache_page(my_view, 60 * 15)),
)

#
# Code snippet 19 ########################################################
#

>>> from django.core.cache import cache

#
# Code snippet 20 ########################################################
#

>>> cache.set('my_key', 'hello, world!', 30)
>>> cache.get('my_key')
'hello, world!'

#
# Code snippet 21 ########################################################
#

# Wait 30 seconds for 'my_key' to expire...

>>> cache.get('my_key')
None

>>> cache.get('some_unset_key')
None

#
# Code snippet 22 ########################################################
#

>>> cache.get('my_key', 'has expired')
'has expired'

#
# Code snippet 23 ########################################################
#

>>> cache.set('a', 1)
>>> cache.set('b', 2)
>>> cache.set('c', 3)
>>> cache.get_many(['a', 'b', 'c'])
{'a': 1, 'b': 2, 'c': 3}

#
# Code snippet 24 ########################################################
#

>>> cache.get_many(['a', 'b', 'c', 'd'])
{'a': 1, 'b': 2, 'c': 3}

#
# Code snippet 25 ########################################################
#

>>> cache.delete('a')

#
# Code snippet 26 ########################################################
#

from django.views.decorators.vary import vary_on_headers

# Python 2.3 syntax.
def my_view(request):
    # ...
my_view = vary_on_headers(my_view, 'User-Agent')

# Python 2.4+ decorator syntax.
@vary_on_headers('User-Agent')
def my_view(request):
    # ...

#
# Code snippet 27 ########################################################
#

@vary_on_headers('User-Agent', 'Cookie')
def my_view(request):
    # ...

#
# Code snippet 28 ########################################################
#

@vary_on_cookie
def my_view(request):
    # ...

@vary_on_headers('Cookie')
def my_view(request):
    # ...

#
# Code snippet 29 ########################################################
#

from django.utils.cache import patch_vary_headers

def my_view(request):
    # ...
    response = render_to_response('template_name', context)
    patch_vary_headers(response, ['Cookie'])
    return response

#
# Code snippet 30 ########################################################
#

from django.views.decorators.cache import cache_control

@cache_control(private=True)
def my_view(request):
    # ...

#
# Code snippet 31 ########################################################
#

from django.views.decorators.cache import cache_control
@cache_control(must_revalidate=True, max_age=3600)
def my_view(request):
    ...

