#
# Code snippet 1 #########################################################
#

def my_view(request):
    output = _("Welcome to my site.")
    return HttpResponse(output)

#
# Code snippet 2 #########################################################
#

from django.utils.translation import gettext
def my_view(request):
    output = gettext("Welcome to my site.")
    return HttpResponse(output)

#
# Code snippet 3 #########################################################
#

def my_view(request):
    words = ['Welcome', 'to', 'my', 'site.']
    output = _(' '.join(words))
    return HttpResponse(output)

#
# Code snippet 4 #########################################################
#

def my_view(request):
    sentence = 'Welcome to my site.'
    output = _(sentence)
    return HttpResponse(output)

#
# Code snippet 5 #########################################################
#

def my_view(request, n):
    output = _('%(name)s is my name.') % {'name': n}
    return HttpResponse(output)

#
# Code snippet 6 #########################################################
#

from django.utils.translation import gettext_lazy

class MyThing(models.Model):
    name = models.CharField(help_text=gettext_lazy('This is the help text'))

#
# Code snippet 7 #########################################################
#

from django.utils.translation import gettext_lazy as _

class MyThing(models.Model):
    name = models.CharField(help_text=_('This is the help text'))

#
# Code snippet 8 #########################################################
#

from django.utils.translation import gettext_lazy as _

class MyThing(models.Model):
    name = models.CharField(_('name'), help_text=_('This is the help text'))
    class Meta:
        verbose_name = _('my thing')
        verbose_name_plural = _('mythings')

#
# Code snippet 9 #########################################################
#

from django.utils.translation import ngettext
def hello_world(request, count):
    page = ngettext(
        'there is %(count)d object',
        'there are %(count)d objects', count
    ) % {'count': count}
    return HttpResponse(page)

#
# Code snippet 10 #########################################################
#

<title>{% trans "This is the title." %}</title>

#
# Code snippet 11 ########################################################
#

<title>{% trans "value" noop %}</title>

#
# Code snippet 12 ########################################################
#

{% blocktrans %}This will have {{ value }} inside.{% endblocktrans %}

#
# Code snippet 13 ########################################################
#

{% blocktrans with value|filter as myvar %}
  This will have {{ myvar }} inside.
{% endblocktrans %}

#
# Code snippet 14 ########################################################
#

{% blocktrans with book|title as book_t and author|title as author_t %}
  This is {{ book_t }} by {{ author_t }}
{% endblocktrans %}

#
# Code snippet 15 ########################################################
#

{% blocktrans count list|length as counter %}
  There is only one {{ name }} object.
{% plural %}
  There are {{ counter }} {{ name }} objects.
{% endblocktrans %}

#
# Code snippet 16 ########################################################
#

{% load i18n %}
{% get_current_language as LANGUAGE_CODE %}
{% get_available_languages as LANGUAGES %}
{% get_current_language_bidi as LANGUAGE_BIDI %}

#
# Code snippet 17 ########################################################
#

{% some_special_tag _("Page not found") value|yesno:_("yes,no") %}

#
# Code snippet 18 ########################################################
#

bin/make-messages.py -l de

#
# Code snippet 19 ########################################################
#

_("Welcome to my site.")

#
# Code snippet 20 ########################################################
#

#: path/to/python/module.py:23
msgid "Welcome to my site."
msgstr ""

#
# Code snippet 21 ########################################################
#

msgid ""
"There's been an error. It's been reported to the site administrators via e-"
"mail and should be fixed shortly. Thanks for your patience."
msgstr ""
"Ha ocurrido un error. Se ha informado a los administradores del sitio "
"mediante correo electr&#243;nico y deber&#237;a arreglarse en breve. Gracias por su "
"paciencia."

#
# Code snippet 22 ########################################################
#

make-messages.py -a

#
# Code snippet 23 ########################################################
#

bin/compile-messages.py

#
# Code snippet 24 ########################################################
#

MIDDLEWARE_CLASSES = (
   'django.middleware.common.CommonMiddleware',
   'django.contrib.sessions.middleware.SessionMiddleware',
   'django.middleware.locale.LocaleMiddleware'
)

#
# Code snippet 25 ########################################################
#

LANGUAGES = (
    ('de', _('German')),
    ('en', _('English')),
)

#
# Code snippet 26 ########################################################
#

_ = lambda s: s

LANGUAGES = (
      ('de', _('German')),
      ('en', _('English')),
)

#
# Code snippet 27 ########################################################
#

def hello_world(request, count):
    if request.LANGUAGE_CODE == 'de-at':
        return HttpResponse("You prefer to read Austrian German.")
    else:
        return HttpResponse("You prefer to read another language.")

#
# Code snippet 28 ########################################################
#

(r'^i18n/', include('django.conf.urls.i18n')),

#
# Code snippet 29 ########################################################
#

<form action="/i18n/setlang/" method="get">
<input name="next" type="hidden" value="/next/page/" />
<select name="language">
{% for lang in LANGUAGES %}
<option value="{{ lang.0 }}">{{ lang.1 }}</option>
{% endfor %}
</select>
<input type="submit" value="Go" />
</form>

#
# Code snippet 30 ########################################################
#

js_info_dict = {
    'packages': ('your.app.package',),
}

urlpatterns = patterns('',
    (r'^jsi18n/$', 'django.views.i18n.javascript_catalog', js_info_dict),
)

#
# Code snippet 31 ########################################################
#

urlpatterns = patterns('',
    (r'^jsi18n/(?P<packages>\S+?)/$, 'django.views.i18n.javascript_catalog'),
)

#
# Code snippet 32 ########################################################
#

<script type="text/javascript" src="/path/to/jsi18n/"></script>

#
# Code snippet 33 ########################################################
#

document.write(gettext('this is to be translated'));

#
# Code snippet 34 ########################################################
#

d = {
    count: 10
};
s = interpolate(ngettext('this is %(count)s object', 'this are %(count)s objects', d.count), d);

#
# Code snippet 35 ########################################################
#

s = interpolate(ngettext('this is %s object', 'this are %s objects', 11), [11]);

#
# Code snippet 36 ########################################################
#

make-messages.py -d djangojs -l de

