#
# Code snippet 1 #########################################################
#

def user_contacts(request):
    user = request.GET['username']
    sql = "SELECT * FROM user_contacts WHERE username = '%s';" % username
    # execute the SQL here...

#
# Code snippet 2 #########################################################
#

SELECT * FROM user_contacts WHERE username = '' OR 'a' = 'a';

#
# Code snippet 3 #########################################################
#

SELECT * FROM user_contacts WHERE username = ''; DELETE FROM user_contacts WHERE 'a' = 'a';

#
# Code snippet 4 #########################################################
#

foo.get_list(bar__exact="' OR 1=1")

#
# Code snippet 5 #########################################################
#

SELECT * FROM foos WHERE bar = '\' OR 1=1'

#
# Code snippet 6 #########################################################
#

from django.db import connection

def user_contacts(request):
    user = request.GET['username']
    sql = "SELECT * FROM user_contacts WHERE username = %s;"
    cursor = connection.cursor()
    cursor.execute(sql, [user])
    # ... do something with the results

#
# Code snippet 7 #########################################################
#

def say_hello(request):
    name = request.GET.get('name', 'world')
    return render_to_response("hello.html", {"name" : name})

#
# Code snippet 8 #########################################################
#

<h1>Hello, {{ name }}!</h1>

#
# Code snippet 9 #########################################################
#

<h1>Hello, Jacob!</h1>

#
# Code snippet 10 #########################################################
#

<h1>Hello, <i>Jacob</i>!</h1>

#
# Code snippet 11 ########################################################
#

<h1>Hello, {{ name|escape }}!</h1>

#
# Code snippet 12 ########################################################
#

To: hardcoded@example.com
Subject: hello
cc: spamvictim@example.com

#
# Code snippet 13 ########################################################
#

def dump_file(request):
    filename = request.GET["filename"]
    filename = os.path.join(BASE_PATH, filename)
    content = open(filename).read()

    # ...

#
# Code snippet 14 ########################################################
#

import os
import posixpath

# ...

path = posixpath.normpath(urllib.unquote(path))
newpath = ''
for part in path.split('/'):
    if not part:
        # strip empty path components
        continue

    drive, part = os.path.splitdrive(part)
    head, part = os.path.split(part)
    if part in (os.curdir, os.pardir):
        # strip '.' and '..' in path
        continue

    newpath = os.path.join(newpath, part).replace('\\', '/')

